#include<iostream>
#include<string>
using namespace std;
int main()	{
	string str;
	cout<<"nhap chuoi ky tu: ";
	getline(cin,str);
	cout<<"do dai cua chuoi la : "<<str.length()<<endl;
	return 0;
	
}
