#include<iostream>
#include<cmath>
using namespace std;
int main()	{
	int x, y, A, B, C, D, E;
	x=18;
	y=2;
	A=y+3;
	B=y-2;
	C=y*5;
	D=x/y;
	E=x%y;
	cout<<"ket qua cua A la : "<<A<<endl;
	cout<<"ket qua cua B la : "<<B<<endl;
	cout<<"ket qua cua C la : "<<C<<endl;
	cout<<"ket qua cua D la : "<<D<<endl;
	cout<<"ket qua cua E la : "<<E<<endl;
	return 0;
}
