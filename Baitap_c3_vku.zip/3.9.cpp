#include<iostream>
using namespace std;
int main() {
double a,b,c,d,e,s;
cout<<"nhap diem kiem tra 1,2,3,gk,ck: ";cin>>a>>b>>c>>d>>e;

s=a+b+c;

cout<<"==========Diem kiem tra=========="<<endl;
cout<<"nhap diem kiem tra 1:"<<a<<endl;
cout<<"nhap diem kiem tra 2:"<<b<<endl;
cout<<"nhap diem kiem tra 3:"<<c<<endl;
cout<<"==========Diem thi giua ky=========="<<endl;
cout<<"nhap diem thi giua ky:"<<d<<endl;
cout<<"==========Diem thi cuoi ky=========="<<endl;
cout<<"nhap diem thi cuoi ky:"<<e<<endl;
cout<<"tong diem kiem tra: "<<s<<endl;
cout<<"diem thi giua ky: "<<d<<endl;
cout<<"diem thi cuoi ky: "<<e<<endl;
return 0;
}
